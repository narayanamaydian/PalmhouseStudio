import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'our-service',
  templateUrl: './our-service.component.html',
  styleUrls: ['./our-service.component.css']
})
export class ServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
